import React from "react";
 
const OutreachFeedback = () => {
    return (
        <div className= 'outreach'>
            <h1>Outreach: Feedback</h1>
        </div>
    );
};



export default OutreachFeedback;