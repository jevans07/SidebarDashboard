import React from "react";
 
const Outreach = () => {
    return (
        <div className= 'outreach'>
            <h1>Outreach</h1>
        </div>
    );
};



export default Outreach;