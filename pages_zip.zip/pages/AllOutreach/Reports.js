import React from "react";
 
const OutreachReports = () => {
    return (
        <div className= 'outreach'>
            <h1>Outreach: Reports</h1>
        </div>
    );
};



export default OutreachReports;