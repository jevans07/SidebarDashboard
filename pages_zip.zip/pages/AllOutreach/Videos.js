import React from "react";
 
const OutreachVideos = () => {
    return (
        <div className= 'outreach'>
            <h1>Outreach: Videos</h1>
        </div>
    );
};



export default OutreachVideos;