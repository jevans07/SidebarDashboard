import React from "react";
 
const OutreachWebinars = () => {
    return (
        <div className= 'outreach'>
            <h1>Outreach: Webinars</h1>
        </div>
    );
};



export default OutreachWebinars;