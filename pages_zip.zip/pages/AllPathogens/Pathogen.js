import React from "react";
 
const Pathogen = () => {
    return (
        <div className='pathogen'>
            <h1>Pathogen</h1>
        </div>
    );
};
 
export default Pathogen;