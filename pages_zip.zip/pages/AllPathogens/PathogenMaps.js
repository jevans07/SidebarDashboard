import React from 'react'

const PathogensMaps = () => {
  return (
    <div className='pathogen'>
      <h1> Pathogens: Maps </h1>
    </div>
  )
}

export default PathogensMaps