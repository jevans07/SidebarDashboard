import React from 'react'

const PathogensProfiles = () => {
  return (
    <div className='pathogen'>
      <h1> Pathogens: Profiles </h1>
    </div>
  )
}

export default PathogensProfiles