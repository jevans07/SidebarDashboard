import React from 'react'

const PathogensSelection = () => {
  return (
    <div className='pathogen'>
      <h1> Pathogens: Selection </h1>
    </div>
  )
}

export default PathogensSelection