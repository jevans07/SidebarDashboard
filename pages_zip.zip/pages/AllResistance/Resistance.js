
import React from "react";
 
const Resistance = () => {
    return (
        <div className = 'resistance'>
            <h1>Resistance</h1>
        </div>
    );
};
 
export default Resistance;