import React from "react";
 
const ResistanceOptions = () => {
    return (
        <div className = 'resistance'>
            <h1>Resistance: Options</h1>
        </div>
    );
};
 
export default ResistanceOptions;