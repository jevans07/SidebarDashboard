import React from "react";

 
const ResistanceProfiles = () => {
    return (
        <div className = 'resistance'>
          <header>
        <h1>Resitance: Profiles</h1>
      </header>
      <main>
        <p>This is where we will be able to give a brief overview of what the website is about and can direct our users 
            to other links where they will be able to gain the information they are searching for.
        </p>
        <img src='https://cms.boardmix.com/images/image/article-images/what-is-hierarchy-diagram.png' width={350} height={350} textAlign="center" alt="Placeholder" />
      </main>
        </div>
    );
};
 
export default ResistanceProfiles;