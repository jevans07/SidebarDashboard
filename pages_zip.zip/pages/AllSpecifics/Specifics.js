import React from 'react'

const Specifics = () => {
  return (
    <div className='specifics'>
      <h1> Specifics </h1>
      <img src= '' width={350} height={350} align-items="center" alt="Placeholder" />
    </div>
  )
}

export default Specifics
