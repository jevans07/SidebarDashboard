import React from 'react'

const SpecificsState = () => {
  return (
    <div className='specifics'>
      <h1> Specifics: States </h1>
    </div>
  )
}

export default SpecificsState